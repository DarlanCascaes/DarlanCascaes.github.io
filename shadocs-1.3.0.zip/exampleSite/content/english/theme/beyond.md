---
weight: 4000
linkTitle: "To infinity and beyond!"
title: "To infinity and beyond!"
description: "What will come next in the theme."
categories: ["Theme"]
---

# Go further
---

# Upcoming features and improvements
---

### Website content
* Documentation enhancement

### New features ideas
* Dark mode

### Shortcodes

### Technical website improvements
* Use of purgeCSS in PostCSS
