---
weight: 2000
title: "Empty simple page"
description: "Sidebar: Empty simple page"
categories: ["Functionalities"]
---
