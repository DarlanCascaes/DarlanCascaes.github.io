---
weight: 11000
title: "404"
description: "How to manage 404 page?"
titleIcon: "fa-solid fa-circle-xmark"
categories: ["Functionalities"]
---

# Description
---

By default a 404 error page is provided by the theme, but a specific one can be defined following the [Hugo documentation](https://gohugo.io/templates/404/).

# Theme page 404
---

* [404](/404.html)
