---
weight: 4000
linkTitle: "Vers l'infini et au-delà !"
title: "Vers l'infini et au-delà !"
description: "Ce qui est prévu par la suite dans le thème."
categories: ["Thème"]
---

# Aller plus loin
---

# Fonctionnalités et améliorations à venir
---

### Contenu du site
* Enrichissement de la documentation

### Idées de nouvelles fonctionnalités
* Dark mode

### Shortcodes

### Optimisations techniques du site
* Utilisation de purgeCSS en PostCSS
