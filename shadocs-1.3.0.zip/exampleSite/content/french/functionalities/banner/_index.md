---
weight: 13000
title: "Bannière"
description: "Comment gérér une bannière ?"
titleIcon: "fa-solid fa-bullhorn"
categories: ["Fonctionnalités"]
tags: ["Gestion du contenu"]
---

# Description
---

Dans le thème, il est possible d'afficher une bannière en haut de la page, en utilisant deux options disponibles:
* [activer le site en tant que site archivé, et afficher une bannière sur toutes les pages](global/)
* [activer une bannière sur une seule page](single/)
