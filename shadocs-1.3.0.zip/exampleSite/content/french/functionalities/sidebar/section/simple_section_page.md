---
weight: 1000
title: "Page simple de section"
description: "Menu latéral: Page simple de section"
categories: ["Fonctionnalités"]
---

# Description
---

Cf. [Page simple](../simple_page/)